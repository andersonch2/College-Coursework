float mypow(int, int);
